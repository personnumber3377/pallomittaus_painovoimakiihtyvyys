import csv
import matplotlib.pyplot as plt


def main():
    # Load Y-values (vertical position) from the CSV
    y_values = []

    with open('data.csv', newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header row
        for row in reader:
            y = float(row[2])  # assuming Y is in 3rd column (index 2)
            y_values.append(y)

    # Time vector (assuming 100 fps)
    frame_count = len(y_values)
    fps = 100
    time = [i / fps for i in range(frame_count)]

    # Plot
    plt.figure(figsize=(8, 5))
    plt.plot(time, y_values, 'bo-', label='Measured position')
    plt.xlabel('Time (s)')
    plt.ylabel('Vertical position (cm)')
    plt.title('Free Fall: Position vs. Time')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

if __name__=="__main__":
    main()
    exit(0)